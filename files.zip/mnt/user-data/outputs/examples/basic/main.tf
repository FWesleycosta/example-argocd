################################################################################
# Exemplo básico de uso do módulo Step Functions
################################################################################

provider "aws" {
  region = "us-east-1"
}

module "step_function" {
  source = "../../"

  name = "minha-state-machine"
  type = "STANDARD"

  definition = jsonencode({
    Comment = "Um exemplo simples de State Machine"
    StartAt = "HelloWorld"
    States = {
      HelloWorld = {
        Type   = "Pass"
        Result = "Hello, World!"
        Next   = "WaitStep"
      }
      WaitStep = {
        Type    = "Wait"
        Seconds = 5
        Next    = "SuccessState"
      }
      SuccessState = {
        Type = "Succeed"
      }
    }
  })

  # Logging (opcional)
  create_log_group      = true
  log_retention_in_days = 14

  # X-Ray tracing (opcional)
  tracing_enabled = true

  # Políticas IAM adicionais (opcional)
  # additional_policy_arns = ["arn:aws:iam::aws:policy/AWSLambda_ReadOnlyAccess"]

  tags = {
    Environment = "dev"
    Project     = "meu-projeto"
  }
}

# Para usar logging_configuration, passe o ARN do log group criado:
#
# module "step_function_with_logging" {
#   source = "../../"
#
#   name       = "sfn-com-logging"
#   definition = jsonencode({ ... })
#
#   create_log_group = true
#
#   logging_configuration = {
#     log_group_arn          = module.step_function_with_logging.log_group_arn
#     include_execution_data = true
#     level                  = "ALL"
#   }
# }

################################################################################
# Outputs
################################################################################

output "state_machine_arn" {
  value = module.step_function.state_machine_arn
}

output "role_arn" {
  value = module.step_function.role_arn
}

# Exemplo de configuração Terraform
# Copie este arquivo para terraform.tfvars e ajuste os valores

# Environment
environment = "dev"

# Lambda Configuration
function_name = "fibra-lambda"
description   = "Fibra Lambda Function"

# Docker Image URI (obrigatório)
# Formato: {account_id}.dkr.ecr.{region}.amazonaws.com/{repository}:{tag}
image_uri = "033659470834.dkr.ecr.us-east-1.amazonaws.com/aws-ecr-node-lab:latest"

# Arquitetura: ["x86_64"] ou ["arm64"]
architectures = ["x86_64"]

lambda_timeout     = 30
lambda_memory_size = 128
log_retention_days = 14

# Environment Variables
environment_variables = {
  NODE_ENV = "production"
}

# IAM - Políticas adicionais (opcional)
additional_policy_arns = [
  # "arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess",
  # "arn:aws:iam::aws:policy/AmazonDynamoDBReadOnlyAccess",
]

# Dead Letter Queue (opcional)
# dead_letter_target_arn = "arn:aws:sqs:us-east-1:123456789012:my-dlq"

# Triggers (opcional)
# allowed_triggers = {
#   api_gateway = {
#     principal  = "apigateway.amazonaws.com"
#     source_arn = "arn:aws:execute-api:us-east-1:123456789012:api-id/*"
#   }
#   sns = {
#     principal  = "sns.amazonaws.com"
#     source_arn = "arn:aws:sns:us-east-1:123456789012:my-topic"
#   }
# }

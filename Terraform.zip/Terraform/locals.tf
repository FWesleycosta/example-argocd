locals {
  tags = {
    Environment = var.environment
    Created_at  = formatdate("DD-MM-YYYY HH:mm:ss 'BRT'", timeadd(timestamp(), "-3h"))
    ManagedBy   = "Terraform"
    Service     = "NomeDoServico" # <-- Alterar para o nome do serviço
    Team        = "SeuNomeDoTime" # <-- Alterar para o nome do time responsável
  }
}
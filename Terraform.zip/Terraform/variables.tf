################
# Environment
################
variable "environment" {
  description = "Nome do ambiente (dev, staging, prod)"
  type        = string
  default     = "dev"
}

##########################
# Lambda Configuration
##########################
variable "function_name" {
  description = "Nome único da função Lambda"
  type        = string
}

variable "description" {
  description = "Descrição da função Lambda"
  type        = string
}

variable "image_uri" {
  description = "URI da imagem Docker no ECR (ex: 123456789012.dkr.ecr.us-east-1.amazonaws.com/my-repo:tag)"
  type        = string
}

variable "architectures" {
  description = "Arquitetura da função Lambda (x86_64 ou arm64)"
  type        = list(string)
  default     = ["x86_64"]
}

variable "lambda_timeout" {
  description = "Timeout da função Lambda em segundos"
  type        = number
  default     = 30
}

variable "lambda_memory_size" {
  description = "Memória alocada para a função Lambda em MB"
  type        = number
  default     = 128
}

variable "environment_variables" {
  description = "Variáveis de ambiente da função Lambda"
  type        = map(string)
  default     = {}
}

variable "log_retention_days" {
  description = "Dias de retenção dos logs no CloudWatch"
  type        = number
  default     = 14
}

variable "dead_letter_target_arn" {
  description = "ARN da fila SQS ou tópico SNS para Dead Letter Queue"
  type        = string
  default     = null
}

#######################
# IAM Configuration
#######################
variable "additional_policy_arns" {
  description = "Lista de ARNs de políticas IAM adicionais para a role da Lambda"
  type        = list(string)
  default     = []
}

###################
# Triggers
###################
variable "allowed_triggers" {
  description = "Mapa de triggers permitidos para invocar a Lambda"
  type = map(object({
    principal  = string
    source_arn = string
  }))
  default = {}
}

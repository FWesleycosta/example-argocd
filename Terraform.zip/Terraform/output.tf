################################################################################
# Lambda Outputs
################################################################################
output "lambda_function_arn" {
  description = "ARN da função Lambda"
  value       = module.lambda.function_arn
}

output "lambda_function_name" {
  description = "Nome da função Lambda"
  value       = module.lambda.function_name
}

output "lambda_invoke_arn" {
  description = "ARN de invocação da função Lambda"
  value       = module.lambda.invoke_arn
}

output "lambda_log_group_name" {
  description = "Nome do CloudWatch Log Group da Lambda"
  value       = module.lambda.log_group_name
}

################################################################################
# IAM Role Outputs
################################################################################
output "lambda_role_arn" {
  description = "ARN da IAM Role da Lambda"
  value       = module.lambda_role.role_arn
}

output "lambda_role_name" {
  description = "Nome da IAM Role da Lambda"
  value       = module.lambda_role.role_name
}

############################
#
#    IAM Role for Lambda
#
############################
module "lambda_role" {
  source = "./modules/aws_iam_role"

  function_name          = var.function_name
  additional_policy_arns = var.additional_policy_arns

  custom_policies = {
    #"dynamodb-read" = jsonencode({
    #  Version = "2012-10-17"
    #  Statement = [{
    #    Effect = "Allow"
    #    Action = [
    #      "dynamodb:GetItem",
    #      "dynamodb:Query",
    #      "dynamodb:Scan",
    #      "dynamodb:BatchGetItem"
    #    ]
    #    Resource = [
    #      "arn:aws:dynamodb:sa-east-1:123456789012:table/MinhaTabela",
    #      "arn:aws:dynamodb:sa-east-1:123456789012:table/MinhaTabela/index/*"       
    #    ]
    #  }]
    #})
  }
  tags = local.tags
}

############################
#
#     Lambda Function
#
############################
module "lambda" {
  source = "./modules/aws_lambda_function"

  create_lambda_function = true

  function_name      = "lambda-examples"
  role               = module.lambda_role.role_arn
  memory_size        = 128
  timeout            = 30
  description        = "Microsserviço Serveless"
  tracing_config     = "PassThrough"
  image_uri          = var.image_uri
  tags               = local.tags
  package_type       = "Image"
  environment        = {}
  subnet_ids         = []
  security_group_ids = []
}

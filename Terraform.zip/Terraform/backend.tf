terraform {
  backend "s3" {
    # Values configured via -backend-config in the pipeline:
    # bucket         = "fibra-terraform-state-${environment}"
    # key            = "fibra/${environment}/terraform.tfstate"
    # region         = "us-east-1"
    # dynamodb_table = "fibra-terraform-locks-${environment}"
    # encrypt        = true
  }
}

output "function_arn" {
  description = "ARN of the Lambda function"
  value       = try(aws_lambda_function.this[0].arn, null)
}

output "function_name" {
  description = "Name of the Lambda function"
  value       = try(aws_lambda_function.this[0].function_name, null)
}

output "invoke_arn" {
  description = "Invoke ARN of the Lambda function"
  value       = try(aws_lambda_function.this[0].invoke_arn, null)
}

output "log_group_name" {
  description = "Name of the CloudWatch Log Group for the Lambda function"
  value       = var.create_lambda_function ? "/aws/lambda/${var.function_name}" : null
}

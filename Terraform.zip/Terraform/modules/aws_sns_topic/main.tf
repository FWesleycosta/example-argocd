resource "aws_sns_topic" "this" {
  name                        = var.fifo_topic ? "${var.topic_name}.fifo" : var.topic_name
  fifo_topic                  = var.fifo_topic
  content_based_deduplication = var.fifo_topic ? var.content_based_deduplication : false

  tags = var.tags
}

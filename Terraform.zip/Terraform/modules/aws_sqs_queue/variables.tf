variable "queue_name" {
  description = "Name of the SQS queue"
  type        = string

  validation {
    condition     = length(var.queue_name) > 0 && length(var.queue_name) <= 80
    error_message = "Queue name must be between 1 and 80 characters."
  }
}

variable "fifo_queue" {
  description = "Whether to create a FIFO queue"
  type        = bool
  default     = false
}

variable "content_based_deduplication" {
  description = "Enable content-based deduplication for FIFO queues"
  type        = bool
  default     = false
}

variable "visibility_timeout_seconds" {
  description = "Visibility timeout for the queue (seconds)"
  type        = number
  default     = 30
}

variable "message_retention_seconds" {
  description = "Message retention period (seconds)"
  type        = number
  default     = 345600 # 4 days
}

variable "receive_wait_time_seconds" {
  description = "Long polling wait time (seconds)"
  type        = number
  default     = 0
}

variable "tags" {
  description = "Tags for the resources"
  type        = map(string)
  default     = {}
}

variable "function_name" {
  description = "Unique name of the Lambda function"
  type        = string

  validation {
    condition     = length(var.function_name) > 0 && length(var.function_name) <= 64
    error_message = "The function name must be between 1 and 64 characters."
  }
}

variable "tags" {
  description = "Tags for the resources"
  type        = map(string)
  default     = {}
}

variable "additional_policy_arns" {
  description = "List of additional IAM policy ARNs to attach to the Lambda role"
  type        = list(string)
  default     = []
}

variable "enable_vpc_access" {
  description = "Enable permissions for Lambda to run in VPC (creates/deletes network interfaces)"
  type        = bool
  default     = false
}

variable "custom_policies" {
  description = "Map of custom inline IAM policies (name => policy JSON). Use to define granular permissions following the principle of least privilege."
  type        = map(string)
  default     = {}
}
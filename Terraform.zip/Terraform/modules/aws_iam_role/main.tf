resource "aws_iam_role" "this" {
  name               = "${var.function_name}-role"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume_role.json

  tags = var.tags
}

resource "aws_iam_role_policy" "logs" {
  name   = "${var.function_name}-logs"
  role   = aws_iam_role.this.id
  policy = data.aws_iam_policy_document.lambda_logs.json
}

resource "aws_iam_role_policy" "vpc" {
  count  = var.enable_vpc_access ? 1 : 0
  name   = "${var.function_name}-vpc"
  role   = aws_iam_role.this.id
  policy = data.aws_iam_policy_document.lambda_vpc[0].json
}

resource "aws_iam_role_policy" "custom" {
  for_each = var.custom_policies

  name   = "${var.function_name}-${each.key}"
  role   = aws_iam_role.this.id
  policy = each.value
}

resource "aws_iam_role_policy_attachment" "additional" {
  for_each = toset(var.additional_policy_arns)

  role       = aws_iam_role.this.name
  policy_arn = each.value
}

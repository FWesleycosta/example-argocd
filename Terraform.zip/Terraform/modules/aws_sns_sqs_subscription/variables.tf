variable "sns_topic_arn" {
  description = "ARN of the SNS topic"
  type        = string
}

variable "sqs_queue_arn" {
  description = "ARN of the SQS queue"
  type        = string
}

variable "sqs_queue_url" {
  description = "URL of the SQS queue (for policy attachment)"
  type        = string
}

variable "raw_message_delivery" {
  description = "Enable raw message delivery (no SNS metadata wrapper)"
  type        = bool
  default     = false
}

variable "filter_policy" {
  description = "JSON filter policy for the subscription"
  type        = string
  default     = null
}

variable "filter_policy_scope" {
  description = "Filter policy scope: MessageAttributes or MessageBody"
  type        = string
  default     = "MessageAttributes"

  validation {
    condition     = contains(["MessageAttributes", "MessageBody"], var.filter_policy_scope)
    error_message = "filter_policy_scope must be MessageAttributes or MessageBody."
  }
}

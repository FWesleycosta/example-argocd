data "aws_iam_policy_document" "sqs_policy" {
  statement {
    sid    = "AllowSNSToSendMessage"
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["sns.amazonaws.com"]
    }

    actions   = ["sqs:SendMessage"]
    resources = [var.sqs_queue_arn]

    condition {
      test     = "ArnEquals"
      variable = "aws:SourceArn"
      values   = [var.sns_topic_arn]
    }
  }
}

resource "aws_sqs_queue_policy" "this" {
  queue_url = var.sqs_queue_url
  policy    = data.aws_iam_policy_document.sqs_policy.json
}

resource "aws_sns_topic_subscription" "this" {
  topic_arn            = var.sns_topic_arn
  protocol             = "sqs"
  endpoint             = var.sqs_queue_arn
  raw_message_delivery = var.raw_message_delivery

  filter_policy       = var.filter_policy
  filter_policy_scope = var.filter_policy != null ? var.filter_policy_scope : null

  depends_on = [aws_sqs_queue_policy.this]
}
